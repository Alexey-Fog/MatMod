﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsApp_MatMod3
{
    class Program
    {
        static double MyFunc(double a)
        {
            return (Math.Pow(Math.E,a) * Math.Sin(a));
        }
        static string Func1() //перебора
        {
            double a = -1,
                b = 0,
                e = 0.000001;
            int n = (int)((b - a) / e) + 1;
            double h = (b - a) / n;
            double x_min = a,
                y_min = MyFunc(a);
            for (int i = 1; i < n; i++)
            {
                double x = a + h * i,
                    y = MyFunc(x);
                if (y < y_min)
                {
                    y_min = MyFunc(x);
                    x_min = x;
                }
            }
            return ($"x_min = {Math.Round(x_min,5)}"+"\n"+$"y_min = {Math.Round(y_min,5)}");
        }
        static string Func2() //дихотомии
        {
            double a = -1,
                b = 0,
                e = 0.000001;
            double x1, x2;
            for (; b-a > 2*e;)
            {
                x1 = (b + a - e) / 2;
                x2 = (b + a + e) / 2;
                if (MyFunc(x1) <= MyFunc(x2))
                {
                    b = x2;
                }
                else
                {
                    a = x1;
                }
            }
            double x_min = (a + b) / 2;
            return ($"x_min = {Math.Round(x_min,5)}"+"\n"+$"y_min = {Math.Round(MyFunc(x_min),5)}");
        }
        static string Func3() //золотого сечения
        {
            double a = -1,
                b = 0,
                e = 0.01;
            double x1, x2, y1, y2;
                x1 = a + (b - a) * (3-Math.Pow(5, 0.5)) / 2;
                x2 = a + b - x1;
                y1 = MyFunc(x1);
                y2 = MyFunc(x2);
            for (; b-a > 2*e;)
            {
                if (y1 <= y2)
                {
                    b = x2;
                    x2 = x1;
                    y2 = y1;
                    x1 = a + b - x2;
                    y1 = MyFunc(x1);
                }
                else
                {
                    a = x1;
                    x1 = x2;
                    y1 = y2;
                    x2 = a + b - x1;
                    y2 = MyFunc(x2);
                }
            }
            double x_min = (a + b) / 2;
            return ($"x_min = {Math.Round(x_min,5)}"+"\n"+$"y_min = {Math.Round(MyFunc(x_min),5)}");
        }

        static void Main(string[] args)
        {
            Console.WriteLine(Func1());
            Console.WriteLine();
            Console.WriteLine(Func2());
            Console.WriteLine();
            Console.WriteLine(Func3());
            Console.ReadKey();
        }
    }
}
