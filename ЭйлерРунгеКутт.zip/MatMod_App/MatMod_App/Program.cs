﻿using System;

namespace MatMod_App
{
    class Program
    {
        public static double MyFunc(double x, double y)
        {
            return 3 / x - y / x;
        }

        static void Main(string[] args)
        {
            Console.WriteLine("3/x-y/x");
            Console.WriteLine("Решение методом Эйлера");
            EulerMethod(1, 0, 2, 0.1);
            Console.WriteLine("Решение уточнённым методом Эйлера");
            ModifiedEulerMethod(1, 0, 2, 0.1);
            Console.WriteLine("Решение методом Рунге-Кутта");
            RungeKutta(1, 0, 2, 0.1);
            Console.ReadKey();
        }

        public static double[] EulerMethod(double x0, double y0, double xMax, double h)
        {
            int n = (int)((xMax - x0) / h) + 1;
            double[] xMass = new double[n];
            double[] yMass = new double[n];

            xMass[0] = x0;
            yMass[0] = y0;
            Console.WriteLine($"{decimal.Round((decimal)xMass[0], 3)}\t{decimal.Round((decimal)yMass[0], 3)}");

            for (int i = 1; i < n; i++)
            {
                xMass[i] = xMass[i - 1] + h;
                yMass[i] = yMass[i - 1] + h * MyFunc(xMass[i - 1], yMass[i - 1]);
                Console.WriteLine($"{decimal.Round((decimal)xMass[i], 4)}\t{decimal.Round((decimal)yMass[i], 4)}");
            }

            return yMass;
        }

        public static double[] ModifiedEulerMethod(double x0, double y0, double xMax, double h)
        {
            int n = (int)((xMax - x0) / h) + 2;
            double[] xMass = new double[n];
            double[] yMass = new double[n];

            xMass[0] = x0;
            yMass[0] = y0;
            Console.WriteLine($"{decimal.Round((decimal)xMass[0], 3)}\t{decimal.Round((decimal)yMass[0], 3)}");

            double x1_2 = x0 + h / 2;
            double y1_2 = y0 + h / 2 * MyFunc(x0, y0);

            xMass[1] = x0 + h;
            yMass[1] = y0 + h * MyFunc(x1_2, y1_2);
            Console.WriteLine($"{decimal.Round((decimal)xMass[1], 3)}\t{decimal.Round((decimal)yMass[1], 3)}");

            for (int i = 2; i < n; i++)
            {
                xMass[i] = xMass[i - 1] + h;
                yMass[i] = yMass[i - 2] + 2 * h * MyFunc(xMass[i - 1], yMass[i - 1]);
                Console.WriteLine($"{decimal.Round((decimal)xMass[i], 3)}\t{decimal.Round((decimal)yMass[i], 3)}");
            }

            return yMass;
        }

        public static double RungeKutta(double x0, double y0, double xmax, double h)
        {
            double a = 0.5;
            double x = x0;
            double y = y0;
            Console.WriteLine($"{decimal.Round((decimal)x, 3)}\t{decimal.Round((decimal)y, 3)}");

            while (x < xmax)
            {
                double k1 = MyFunc(x, y);
                double k2 = MyFunc(x + h / (2 * a), y + h / (2 * a) * k1);

                y = y + h * ((1 - a) * k1 + a * k2);
                x = x + h;
                Console.WriteLine($"{decimal.Round((decimal)x, 3)}\t{decimal.Round((decimal)y, 3)}");
            }

            return y;
        }

    }
}
