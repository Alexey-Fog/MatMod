﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MatMod_App2
{
    class Program
    {
        static void Main(string[] args)
        {
            //найти L(x) max
            //L(x) = 2*x1 + 4*x2 + 5*x3
            double[] massC = { 2, 1, 2, 4 };
            //3*x2 + 2*x3 <= 5
            //2*x1 - x3 >= 4
            double[,] massA =
                {
                    { 1, 1, 0, 3, 1, 0, 0, 0, 14 },
                    { 2, 3, 1, 0, 0, 1, 0, 0, 33 },
                    { 4, 1, 2, 4, 0, 0, 1, 0, 19 },
                    { 3, 1, 2, 3, 0, 0, 0, 1, 15 }
                };
            SimplexMethod.Solve(massC, massA);
        }
    }
    class SimplexMethod
    {
        public static void Solve(double[] massC, double[,] massA)
        {
            int numC = massC.Length; //значения C в функции
            int numAi = massA.GetLength(0); //кол-во строк (потом +1)
            int numAj = massA.GetLength(1); //кол-во столбцов

            double[,] table = new double[numAi + 1, numAj];

            for (int i = 0; i < numAi; i++)
            {
                for (int j = 0; j < numAj; j++)
                {
                    table[i, j] = massA[i, j];
                }
            }

            for (int j = 0; j < numC; j++)
            {
                table[numAi, j] = massC[j];
            }

            while (HasPositive(table))
            {
                //find pos indexes
                //количество положительных чисел в нижней строке
                int countPos = 0;
                for (int j = 0; j < numAj - 1; j++)
                {
                    if (table[numAi, j] > 0) countPos++;
                }
                //ищем индексы положительных чисел в нижней строке
                int[] posJs = new int[countPos];
                for (int j = 0, iId = 0; j < numAj - 1; j++)
                {
                    if (table[numAi, j] > 0) posJs[iId++] = j;
                }
                //minjbi/aij
                //ищем манимальное произведение bi/aij в столбце
                double[] minjbiaij = new double[countPos];
                //запоминаем i строки с манимальным произведением bi/aij в столбце
                int[] minjbiaij_i = new int[countPos];
                for (int jPosId = 0; jPosId < countPos; jPosId++)
                {
                    minjbiaij[jPosId] = 0.0;
                    minjbiaij_i[jPosId] = -1;
                    for (int i = 0; i < numAi; i++)
                    {
                        if (table[i, posJs[jPosId]] == 0)
                            continue; //aij = 0 - не учитывать
                        double value = table[i, numAj-1]/ table[i, posJs[jPosId]];
                        if (value < 0.0 || (minjbiaij[jPosId] != 0.0 && value >= minjbiaij[jPosId])) 
                            continue; //<0 или не меньше
                        minjbiaij[jPosId] = value;
                        minjbiaij_i[jPosId] = i;
                    }
                }
                //cj * minj*bi/aij
                for (int index = 0; index < countPos; index++)
                {
                    if (minjbiaij_i[index] == -1) continue;
                    minjbiaij[index] *= table[numAi, posJs[index]];
                }
                //max(cj * minj*bi/aij)
                int maxElIndex = 0;
                for (int index = 0; index < countPos; index++)
                {
                    if (minjbiaij[index] != 0.0 && minjbiaij[maxElIndex] < minjbiaij[index])
                        maxElIndex = index;
                }
                //akp = akp - aip * akj / aij
                for (int i = 0; i < numAi + 1; i++)
                {
                    if (i == minjbiaij_i[maxElIndex]) continue;
                    for (int j = 0; j < numAj; j++)
                    {
                        if (j == posJs[maxElIndex]) continue;
                        table[i, j] -= table[i, posJs[maxElIndex]] * table[minjbiaij_i[maxElIndex], j] / table[minjbiaij_i[maxElIndex], posJs[maxElIndex]];
                    }
                }
                for (int j = 0; j < numAj; j++)
                {
                    if (j == posJs[maxElIndex]) continue;
                    table[minjbiaij_i[maxElIndex], j] /= table[minjbiaij_i[maxElIndex], posJs[maxElIndex]];
                }
                for (int i = 0; i < numAi + 1; i++) table[i, posJs[maxElIndex]] = 0;
                table[minjbiaij_i[maxElIndex], posJs[maxElIndex]] = 1;
            }
            double[] result = new double[numC];
            for (int j = 0; j < numC; j++)
            {
                if (table[numAi,j] < 0)
                {
                    result[j] = 0;
                }
                else
                {
                    for (int i = 0; i < numAi; i++)
                    {
                        if (table[i,j] == 1.0)
                        {
                            result[j] = table[i, numAj-1];
                            break;
                        }
                    }
                }
            }
            //for (int i = 0; i < table.GetLength(0); i++)
            //{
            //    for (int j = 0; j < table.GetLength(1); j++)
            //    {
            //        Console.Write("\t"+table[i, j]);
            //    }
            //    Console.Write("\n");
            //}
            Console.WriteLine("Результат:");
            for (int i = 0; i < numC; i++)
            {
                Console.WriteLine("x{0} = {1}", i + 1, result[i]);
            }
            for (int i = numC, index = 1; i < table.GetLength(1)-1; i++)
            {
                Console.WriteLine("y{0} = {1}", index++, (-1 * table[table.GetLength(0)-1,i]));
            }
            Console.WriteLine("L(x) max = " + (-1 * table[table.GetLength(0)-1, table.GetLength(1)-1]));
            Console.ReadKey();
        }

        private static bool HasPositive(double[,] table)
        {
            int numVariables = table.GetLength(1);
            for (int j = 0; j < numVariables; j++)
            {
                if (table[table.GetLength(0) - 1, j] > 0)
                {
                    return true;
                }
            }
            return false;
        }
    }
}